# OpenMic Bridge — Native Client Wire Protocol (v1)

Used by `native/android/` → `native/linux/receiver.py`.
Not used by the `web/` variant, which streams over WebSocket instead
(ordered/reliable by TCP, so this framing isn't needed there).

## Transport

UDP. Default port 5450 (configurable).

## Frame format

Sent roughly every 20ms while streaming.

| Field           | Type          | Size    | Notes                          |
|-----------------|---------------|---------|---------------------------------|
| seq_num         | uint32, LE    | 4 bytes | Increments per frame, wraps at 2^32 |
| sample_rate     | uint16, LE    | 2 bytes | e.g. 16000, 44100, 48000        |
| channels        | uint8         | 1 byte  | 1 = mono                        |
| bits_per_sample | uint8         | 1 byte  | 16                               |
| payload_len     | uint16, LE    | 2 bytes | Length of payload in bytes      |
| payload         | raw PCM       | payload_len bytes | little-endian signed 16-bit |

Header is 10 bytes total, followed immediately by the payload.

## Not yet implemented (v1 limitations)

- No discovery — IP address entered manually on the Android side.
- No encryption — fine for a trusted home network; do not expose this
  port to the open internet.
- No forward error correction — the receiver logs packet loss but does
  not attempt to recover lost frames.
