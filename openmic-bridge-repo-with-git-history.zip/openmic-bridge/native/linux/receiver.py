#!/usr/bin/env python3
"""
OpenMic Bridge — Linux receiver
Listens for PCM audio over UDP from the Android client and plays it
into a PipeWire/PulseAudio virtual sink, which is remapped into a
virtual microphone source that any app (Zoom, Discord, OBS, browsers,
etc.) can select as an input device.

Usage:
    python3 receiver.py [--port 5450] [--rate 16000]

Requires: pactl, paplay (part of pipewire-pulse / pulseaudio-utils,
installed by default on Ubuntu 24.04+).
"""

import argparse
import socket
import struct
import subprocess
import sys
import time

HEADER = struct.Struct("<IHBBH")  # seq(u32), rate(u16), channels(u8), bits(u8), payload_len(u16)
HEADER_SIZE = HEADER.size

SINK_NAME = "openmic_sink"
SOURCE_NAME = "openmic_bridge"


def run_cmd(cmd, ignore_errors=False):
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0 and not ignore_errors:
        print(f"Command failed: {' '.join(cmd)}\n{result.stderr.strip()}", file=sys.stderr)
    return result


def module_loaded(name_filter):
    result = run_cmd(["pactl", "list", "short", "modules"])
    return name_filter in result.stdout


def setup_virtual_mic():
    """Create the null sink + remap source if they don't already exist."""
    sinks = run_cmd(["pactl", "list", "short", "sinks"]).stdout
    if SINK_NAME not in sinks:
        run_cmd(["pactl", "load-module", "module-null-sink",
                  f"sink_name={SINK_NAME}", "sink_properties=device.description=OpenMicBridge_Sink"])

    sources = run_cmd(["pactl", "list", "short", "sources"]).stdout
    if SOURCE_NAME not in sources:
        run_cmd(["pactl", "load-module", "module-remap-source",
                  f"master={SINK_NAME}.monitor", f"source_name={SOURCE_NAME}",
                  "source_properties=device.description=OpenMicBridge"])

    print(f"[ok] Virtual microphone '{SOURCE_NAME}' is ready.")
    print(f"     Select '{SOURCE_NAME}' (or 'OpenMicBridge') as the mic input in your apps.")


def teardown_virtual_mic():
    """Best-effort cleanup on exit (does not unload other users' modules)."""
    result = run_cmd(["pactl", "list", "short", "modules"])
    for line in result.stdout.splitlines():
        parts = line.split("\t")
        if len(parts) >= 2 and ("module-null-sink" in parts[1] or "module-remap-source" in parts[1]):
            if SINK_NAME in line or SOURCE_NAME in line:
                run_cmd(["pactl", "unload-module", parts[0]], ignore_errors=True)


def start_player(rate, channels):
    """Spawn paplay writing raw PCM into the virtual sink."""
    return subprocess.Popen(
        [
            "paplay",
            "--raw",
            f"--device={SINK_NAME}",
            f"--rate={rate}",
            f"--channels={channels}",
            "--format=s16le",
        ],
        stdin=subprocess.PIPE,
    )


def main():
    parser = argparse.ArgumentParser(description="OpenMic Bridge — Linux receiver")
    parser.add_argument("--port", type=int, default=5450, help="UDP port to listen on (default 5450)")
    parser.add_argument("--no-teardown", action="store_true",
                         help="Don't remove the virtual mic modules on exit")
    args = parser.parse_args()

    setup_virtual_mic()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(("0.0.0.0", args.port))
    print(f"[ok] Listening for audio on UDP port {args.port}...")
    print("     Waiting for the Android app to connect. Press Ctrl+C to stop.\n")

    player = None
    player_rate = None
    player_channels = None
    expected_seq = None
    packets_received = 0
    last_stats_time = time.time()

    try:
        while True:
            data, addr = sock.recvfrom(65536)
            if len(data) < HEADER_SIZE:
                continue

            seq, rate, channels, bits, plen = HEADER.unpack_from(data, 0)
            payload = data[HEADER_SIZE:HEADER_SIZE + plen]

            if player is None or rate != player_rate or channels != player_channels:
                if player is not None:
                    player.stdin.close()
                    player.wait()
                player = start_player(rate, channels)
                player_rate = rate
                player_channels = channels
                print(f"[ok] Streaming from {addr[0]} @ {rate} Hz, {channels} ch")

            if expected_seq is not None:
                gap = (seq - expected_seq) & 0xFFFFFFFF
                if 0 < gap < 1000:
                    print(f"[warn] packet loss: {gap} frame(s) dropped")
            expected_seq = (seq + 1) & 0xFFFFFFFF

            try:
                player.stdin.write(payload)
            except BrokenPipeError:
                print("[error] paplay exited unexpectedly — is pipewire-pulse running?", file=sys.stderr)
                player = None
                continue

            packets_received += 1
            now = time.time()
            if now - last_stats_time > 10:
                print(f"[stats] {packets_received} packets received in last 10s")
                packets_received = 0
                last_stats_time = now

    except KeyboardInterrupt:
        print("\n[ok] Stopping...")
    finally:
        if player is not None:
            try:
                player.stdin.close()
                player.wait(timeout=2)
            except Exception:
                pass
        if not args.no_teardown:
            teardown_virtual_mic()
            print("[ok] Virtual mic modules removed.")


if __name__ == "__main__":
    main()
