#!/usr/bin/env bash
# OpenMic Bridge — Step 1 sanity check.
# Proves the PipeWire virtual mic path works with NO network/Android
# involved. Run this before touching the Android app at all.
#
# Usage: ./test_virtual_mic.sh

set -e

SINK_NAME="openmic_sink"
SOURCE_NAME="openmic_bridge"

echo "== Checking audio server =="
pactl info | grep "Server Name" || true
echo

echo "== Creating virtual mic (if not already present) =="
pactl list short sinks | grep -q "$SINK_NAME" || \
    pactl load-module module-null-sink sink_name="$SINK_NAME"
pactl list short sources | grep -q "$SOURCE_NAME" || \
    pactl load-module module-remap-source master="${SINK_NAME}.monitor" source_name="$SOURCE_NAME"

echo "== Confirming source exists =="
pactl list sources short | grep "$SOURCE_NAME"
echo

TESTFILE="/usr/share/sounds/alsa/Front_Center.wav"
if [ ! -f "$TESTFILE" ]; then
    echo "Test WAV not found at $TESTFILE — install alsa-utils, or point"
    echo "this script at any .wav file you have on disk."
    exit 1
fi

echo "== Recording 3 seconds from the virtual mic while playing a test tone =="
echo "   (you should hear nothing on your speakers — audio goes only into the virtual sink)"
parec --device="$SOURCE_NAME" --raw > /tmp/openmic_test.raw &
REC_PID=$!

paplay --device="$SINK_NAME" "$TESTFILE"

sleep 1
kill "$REC_PID" 2>/dev/null || true
wait "$REC_PID" 2>/dev/null || true

SIZE=$(stat -c%s /tmp/openmic_test.raw 2>/dev/null || echo 0)
echo
if [ "$SIZE" -gt 1000 ]; then
    echo "[PASS] Captured $SIZE bytes at /tmp/openmic_test.raw — virtual mic path works."
    echo "       Play it back with:"
    echo "       aplay -f S16_LE -r 44100 -c 2 /tmp/openmic_test.raw"
else
    echo "[FAIL] Almost no data captured ($SIZE bytes). Check that pipewire-pulse"
    echo "       is running: systemctl --user status pipewire-pulse"
fi
