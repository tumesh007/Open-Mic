package com.openmicbridge

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.openmicbridge.service.AudioCaptureService

class MainActivity : ComponentActivity() {

    private var micGranted = mutableStateOf(false)

    private val requestMicPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> micGranted.value = granted }

    private val requestNotificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* not fatal if denied on Android 13+ */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        micGranted.value = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            OpenMicBridgeApp(
                micGranted = micGranted.value,
                onRequestMicPermission = {
                    requestMicPermission.launch(Manifest.permission.RECORD_AUDIO)
                },
                onStart = { host, port ->
                    val intent = Intent(this, AudioCaptureService::class.java)
                        .putExtra(AudioCaptureService.EXTRA_HOST, host)
                        .putExtra(AudioCaptureService.EXTRA_PORT, port)
                    ContextCompat.startForegroundService(this, intent)
                },
                onStop = {
                    stopService(Intent(this, AudioCaptureService::class.java))
                }
            )
        }
    }
}

@Composable
fun OpenMicBridgeApp(
    micGranted: Boolean,
    onRequestMicPermission: () -> Unit,
    onStart: (String, Int) -> Unit,
    onStop: () -> Unit
) {
    var host by remember { mutableStateOf("192.168.1.100") }
    var portText by remember { mutableStateOf("5450") }
    var streaming by remember { mutableStateOf(false) }

    MaterialTheme {
        Surface {
            Column(modifier = Modifier.padding(24.dp)) {
                Text("OpenMic Bridge", style = MaterialTheme.typography.headlineSmall)
                Spacer(modifier = Modifier.height(24.dp))

                OutlinedTextField(
                    value = host,
                    onValueChange = { host = it },
                    label = { Text("PC IP address") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = portText,
                    onValueChange = { portText = it },
                    label = { Text("Port") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(16.dp))

                if (!micGranted) {
                    Text("Microphone permission is required.")
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = onRequestMicPermission) {
                        Text("Grant microphone permission")
                    }
                } else {
                    Button(onClick = {
                        if (streaming) {
                            onStop()
                        } else {
                            val port = portText.toIntOrNull() ?: 5450
                            onStart(host, port)
                        }
                        streaming = !streaming
                    }) {
                        Text(if (streaming) "Stop streaming" else "Start streaming")
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
                Row {
                    Text(if (streaming) "Status: streaming to $host:$portText" else "Status: idle")
                }
            }
        }
    }
}
