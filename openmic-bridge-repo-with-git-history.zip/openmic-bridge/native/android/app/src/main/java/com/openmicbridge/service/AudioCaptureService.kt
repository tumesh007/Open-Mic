package com.openmicbridge.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Captures microphone audio and streams it as raw 16-bit PCM over UDP
 * to the Linux receiver. Runs as a foreground service so Android
 * doesn't kill mic access when the app is backgrounded.
 *
 * Wire format (10-byte header + payload), see /protocol/PROTOCOL.md:
 *   uint32 seq_num (LE)
 *   uint16 sample_rate (LE)
 *   uint8  channels
 *   uint8  bits_per_sample
 *   uint16 payload_len (LE)
 *   <payload_len bytes of PCM>
 */
class AudioCaptureService : Service() {

    private var job: Job = SupervisorJob()
    private val scope by lazy { CoroutineScope(Dispatchers.IO + job) }

    private var socket: DatagramSocket? = null
    private var seq: Int = 0

    companion object {
        const val CHANNEL_ID = "openmic_capture_channel"
        const val NOTIFICATION_ID = 1
        const val SAMPLE_RATE = 16000
        const val FRAME_MS = 20
        const val FRAME_SAMPLES = SAMPLE_RATE * FRAME_MS / 1000 // 320 samples per frame
        const val EXTRA_HOST = "host"
        const val EXTRA_PORT = "port"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val host = intent?.getStringExtra(EXTRA_HOST)
        val port = intent?.getIntExtra(EXTRA_PORT, 5450) ?: 5450

        if (host.isNullOrBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())

        socket = DatagramSocket()
        val address = InetAddress.getByName(host)
        scope.launch { captureLoop(address, port) }

        return START_STICKY
    }

    @Suppress("MissingPermission") // RECORD_AUDIO checked by MainActivity before starting this service
    private fun captureLoop(address: InetAddress, port: Int) {
        val minBufferSize = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBufferSize <= 0) {
            stopSelf()
            return
        }

        val recorder = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBufferSize, FRAME_SAMPLES * 2 * 4)
        )

        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            stopSelf()
            return
        }

        val pcmBuffer = ShortArray(FRAME_SAMPLES)
        recorder.startRecording()

        try {
            while (scope.isActive) {
                val read = recorder.read(pcmBuffer, 0, FRAME_SAMPLES)
                if (read <= 0) continue

                val payload = ByteBuffer.allocate(read * 2).order(ByteOrder.LITTLE_ENDIAN)
                for (i in 0 until read) payload.putShort(pcmBuffer[i])

                val header = ByteBuffer.allocate(10).order(ByteOrder.LITTLE_ENDIAN)
                header.putInt(seq)
                header.putShort(SAMPLE_RATE.toShort())
                header.put(1)                       // channels
                header.put(16)                       // bits per sample
                header.putShort((read * 2).toShort()) // payload length in bytes
                seq++

                val packetBytes = header.array() + payload.array()
                socket?.send(DatagramPacket(packetBytes, packetBytes.size, address, port))
            }
        } catch (e: Exception) {
            // Socket closed on stop, or network error — exit the loop quietly.
        } finally {
            recorder.stop()
            recorder.release()
        }
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Microphone streaming",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("OpenMic Bridge")
            .setContentText("Streaming microphone to PC")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        job.cancel()
        socket?.close()
        super.onDestroy()
    }
}
