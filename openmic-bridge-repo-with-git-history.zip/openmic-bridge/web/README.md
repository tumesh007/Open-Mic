# OpenMic Bridge — Web Variant

Phone acts as a mic input for Ubuntu with **no Android app** — just a
browser tab. Trade-off vs the native client: the browser tab must stay
in the foreground with the screen on. If you background the tab or lock
the phone, streaming will likely stop or glitch (behavior varies by
Android/Chrome version — this is a real limitation, not a bug to fix).

## Requirements

- Ubuntu with PipeWire (default on 24.04+)
- Python 3 with `aiohttp`: `pip install aiohttp --break-system-packages`
- Phone and PC on the same WiFi network
- Any modern mobile browser (Chrome recommended)

## The one gotcha: secure context

Browsers block microphone access (`getUserMedia`) on plain `http://`
unless the origin is `localhost`. Your PC's LAN IP doesn't qualify, so
you need ONE of the following, done once:

### Option A — Chrome flag (recommended, no certificates needed)

1. On your **phone**, open Chrome and go to:
   `chrome://flags/#unsafely-treat-insecure-origin-as-secure`
2. Set it to **Enabled**.
3. In the text box that appears, add your PC's address, e.g.:
   `http://192.168.1.100:8080`
4. Tap **Relaunch** at the bottom.

This only affects that one address on that one phone/browser — it does
not weaken security for any other site.

**Note:** the flag matches the exact address you type, including
whether it's an IP or hostname. If you later switch to the `.local`
hostname (see "Making it permanent" below), add that as a *second*
entry in the same flag rather than replacing the IP one — otherwise
the hostname version won't have mic permission even though the IP
version did.

### Option B — self-signed HTTPS certificate

If you'd rather not touch browser flags (e.g. you want other people's
phones to connect too), generate a self-signed cert and run the server
with SSL. You'll get a one-time "connection not private" warning to
click through on each phone. Ask if you want this variant of
`server.py` — it's a small change (wrap the aiohttp app with an
`ssl.SSLContext`).

## Running it

```bash
cd openmic-bridge-web
python3 server.py --port 8080
```

The script will:
1. Create the PipeWire virtual mic (`openmic_bridge`), same as the
   native-client version — if you already ran `receiver.py` before,
   this reuses the same sink/source names, so don't run both at once.
2. Print the URL to open on your phone.

On your phone: open `http://<this-PC's-LAN-IP>:8080`, tap **Start
streaming**, grant mic permission. In your desktop app (Zoom, Discord,
OBS, browser), select **OpenMicBridge** as the microphone input.

## Making it permanent (auto-start + no IP typing)

### 1. Auto-start the server on boot

```bash
cd openmic-bridge-web
./install_autostart.sh
```

This checks for and installs everything needed — audio (`pactl`/`paplay`
via `apt`, `aiohttp` via `pip`/`apt`) and video (`ffmpeg`, `v4l2loopback`).
For video specifically, it:
- Tries Ubuntu's packaged `v4l2loopback-dkms` first.
- Falls back to building the current upstream source if the packaged
  version fails on your kernel (this happened on a newer kernel during
  development — the packaged source predated a kernel API change).
- Writes `/etc/modprobe.d/` and `/etc/modules-load.d/` config so the
  virtual camera exists automatically on every boot, with no `sudo`
  needed at runtime (required — systemd user services can't prompt for
  a password, so without this, video would silently fail on every
  reboot even though it worked when tested manually).
- Adds your user to the `video` group if needed (tells you to log out
  and back in — group membership doesn't apply to your current
  session).

If video setup fails for any reason, the script continues and installs
audio-only — nothing about the working mic path is put at risk by a
video failure. It then installs a systemd **user** service, copies the
project to `~/openmic-bridge-web`, enables `linger` so it starts at
boot even before you log in, and verifies the service actually started.
Safe to re-run on a machine you've already set up, or a brand new one.

Useful commands afterward:
```bash
systemctl --user status openmic-bridge-web.service     # is it running?
journalctl --user -u openmic-bridge-web.service -f      # live logs
systemctl --user stop openmic-bridge-web.service        # stop for now
systemctl --user disable openmic-bridge-web.service     # stop autostarting
```

### 2. Skip typing the IP — use your PC's hostname instead

Ubuntu ships `avahi-daemon` by default, which broadcasts your PC's
hostname over mDNS. Instead of looking up the LAN IP every time, try:

```
http://<your-pc-hostname>.local:8080
```

(Find your hostname with `hostname` in a terminal.) If `.local`
doesn't resolve on your phone, your router/WiFi network is blocking
mDNS — fall back to the numeric IP, or set a static IP for the PC in
your router settings so at least the IP itself never changes.

### 3. The phone side — one tap instead of typing a URL

Nothing runs automatically here; a website can't be pushed open on
your phone. But once you've done the Chrome flag step and visited the
page once, use Chrome's menu → **"Add to Home Screen"**. That gives
you an icon that opens straight to the mic page — closest you'll get
to "just tap and go" without building a native app.

## Finding your PC's LAN IP

```bash
ip addr show | grep "inet " | grep -v 127.0.0.1
```

## How it works

- `public/index.html` — UI, requests mic access, opens a WebSocket to
  `/ws`, sends a JSON `{type: "start", sampleRate, channels}` handshake
  then streams raw 16-bit PCM as binary WebSocket frames.
- `public/audio-processor.js` — an `AudioWorkletProcessor` running on
  the browser's dedicated audio thread; converts Float32 samples from
  the mic to Int16 PCM and hands them to the main thread.
- `server.py` — aiohttp server. Serves the page, and on the `/ws`
  route spawns `paplay` writing into the `openmic_sink` PipeWire sink
  at whatever sample rate the phone's browser reports (no fixed rate
  — avoids downsampling artifacts).

No custom protocol header is needed here (unlike the UDP native-client
version) because WebSocket runs over TCP: ordered, reliable delivery,
so there's no packet loss/reordering to handle in v1.

## Experimental: video (webcam) support

**Independent of the working audio path** — enabling this cannot break
your existing mic setup; it's a separate WebSocket route and a
separate opt-in button on the page.

### One-time setup

```bash
sudo apt install v4l2loopback-dkms ffmpeg
```

`v4l2loopback-dkms` rebuilds itself against your kernel on every kernel
update — this is the same driver-fragility trade-off flagged when this
idea first came up, unavoidable on Linux for virtual cameras (unlike
audio, which PipeWire handles in userspace).

### Running it

```bash
python3 server.py --port 8080 --video
```

Without `--video`, the server behaves exactly as before — nothing about
your current setup changes unless you explicitly add this flag.

On the phone page, a second section appears with its own "Start video"
button, independent of the audio "Start streaming" button — use both,
either, or neither.

### Status

Confirmed working end-to-end (v2). Known rough edges, still real:
- Frame rate is fixed at ~10fps in the client for bandwidth safety —
  visibly laggy, usable for casual video, not smooth. Configurable via
  `VIDEO_FRAME_INTERVAL_MS` in `index.html` if you want to try tuning
  it, but that trades bandwidth/CPU for smoothness — untested past the
  current default.
- No resolution negotiation — uses whatever the browser's default
  camera resolution is.
- No reconnect logic on the video WebSocket yet (audio has it, video
  doesn't) — a dropped connection needs a manual Stop/Start.
- Requires the `video` group and a persistent v4l2loopback module load
  at boot — both handled by `install_autostart.sh`, but if you set this
  up manually instead, see that script for the exact steps.

## Known limitations (be upfront with yourself about these)


- Screen must stay on; tab must stay foregrounded. No foreground-service
  equivalent exists for a website.
- No mDNS auto-discovery — you type the IP once, same as the native
  client's v1.
- No authentication — anyone on your WiFi who knows the port can
  connect. Fine for a home network; don't expose this port outside
  your LAN.

## Reconnect behavior

If the WebSocket drops mid-stream (WiFi blip, server restart, phone
briefly switching networks), the page detects the close event and
retries automatically with exponential backoff (1s, 2s, 4s... capped
at 10s). The mic and audio pipeline stay alive throughout — audio
frames are simply dropped while disconnected, and streaming resumes
once the socket reconnects, with no need to tap Start again. The
status line shows "Connection lost — reconnecting..." during this.
Tapping **Stop** manually always wins — it cancels any pending
reconnect attempt.
