#!/usr/bin/env bash
# Sets up OpenMic Bridge (web variant) to auto-start on login/boot.
set -e

INSTALL_DIR="$HOME/openmic-bridge-web"
SERVICE_DIR="$HOME/.config/systemd/user"

echo "== Installing to $INSTALL_DIR =="
mkdir -p "$INSTALL_DIR"
# Copy everything except this script and the service file (installed separately below)
rsync -a --exclude 'install_autostart.sh' --exclude '*.service' ./ "$INSTALL_DIR/" 2>/dev/null || \
  cp -r ./* "$INSTALL_DIR/" 2>/dev/null

echo "== Installing systemd user service =="
mkdir -p "$SERVICE_DIR"
cp openmic-bridge-web.service "$SERVICE_DIR/"

echo "== Enabling linger, so the service starts at boot even before you log in =="
loginctl enable-linger "$USER"

echo "== Reloading systemd and enabling the service =="
systemctl --user daemon-reload
systemctl --user enable --now openmic-bridge-web.service

echo
echo "[ok] Done. The server will now start automatically on every boot."
echo
echo "Check status any time with:"
echo "    systemctl --user status openmic-bridge-web.service"
echo "View logs with:"
echo "    journalctl --user -u openmic-bridge-web.service -f"
echo "Stop it with:"
echo "    systemctl --user stop openmic-bridge-web.service"
echo "Disable autostart entirely with:"
echo "    systemctl --user disable openmic-bridge-web.service"
