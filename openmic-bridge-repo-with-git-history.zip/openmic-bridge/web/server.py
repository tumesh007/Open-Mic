#!/usr/bin/env python3
"""
OpenMic Bridge — Web variant server.

Serves the phone-side web page (public/) and accepts a WebSocket audio
stream from it, piping the PCM into the same PipeWire virtual mic used
by the native-client version (openmic_sink / openmic_bridge).

No Android app, no build step on the phone side — just a browser.

Usage:
    python3 server.py [--port 8080]

Requires: aiohttp (pip install aiohttp --break-system-packages)
          pactl / paplay (pipewire-pulse, default on Ubuntu 24.04+)
"""

import argparse
import asyncio
import json
import subprocess
import sys
from pathlib import Path

from aiohttp import web, WSMsgType

SINK_NAME = "openmic_sink"
SOURCE_NAME = "openmic_bridge"
PUBLIC_DIR = Path(__file__).parent / "public"


def run_cmd(cmd, ignore_errors=False):
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0 and not ignore_errors:
        print(f"[warn] command failed: {' '.join(cmd)}\n{result.stderr.strip()}", file=sys.stderr)
    return result


def setup_virtual_mic():
    sinks = run_cmd(["pactl", "list", "short", "sinks"]).stdout
    if SINK_NAME not in sinks:
        run_cmd(["pactl", "load-module", "module-null-sink",
                  f"sink_name={SINK_NAME}", "sink_properties=device.description=OpenMicBridge_Sink"])
    sources = run_cmd(["pactl", "list", "short", "sources"]).stdout
    if SOURCE_NAME not in sources:
        run_cmd(["pactl", "load-module", "module-remap-source",
                  f"master={SINK_NAME}.monitor", f"source_name={SOURCE_NAME}",
                  "source_properties=device.description=OpenMicBridge"])
    print(f"[ok] Virtual mic '{SOURCE_NAME}' ready — select it as the input device in your apps.")


async def index(request):
    return web.FileResponse(PUBLIC_DIR / "index.html")


async def websocket_handler(request):
    ws = web.WebSocketResponse(max_msg_size=1024 * 64)
    await ws.prepare(request)

    player = None
    print(f"[ok] Phone connected from {request.remote}")

    try:
        async for msg in ws:
            if msg.type == WSMsgType.TEXT:
                data = json.loads(msg.data)
                if data.get("type") == "start":
                    rate = int(data["sampleRate"])
                    channels = int(data.get("channels", 1))
                    if player is not None:
                        player.stdin.close()
                        player.wait()
                    player = subprocess.Popen(
                        ["paplay", "--raw", f"--device={SINK_NAME}",
                         f"--rate={rate}", f"--channels={channels}",
                         "--format=s16le"],
                        stdin=subprocess.PIPE,
                    )
                    print(f"[ok] Streaming started @ {rate} Hz, {channels} ch")
                elif data.get("type") == "stop":
                    if player is not None:
                        player.stdin.close()
                        player.wait()
                        player = None
                    print("[ok] Streaming stopped")

            elif msg.type == WSMsgType.BINARY:
                if player is not None:
                    try:
                        player.stdin.write(msg.data)
                    except BrokenPipeError:
                        print("[error] paplay died — is pipewire-pulse running?", file=sys.stderr)
                        player = None

            elif msg.type == WSMsgType.ERROR:
                print(f"[error] websocket error: {ws.exception()}", file=sys.stderr)

    finally:
        if player is not None:
            try:
                player.stdin.close()
                player.wait(timeout=2)
            except Exception:
                pass
        print("[ok] Phone disconnected")

    return ws


def main():
    parser = argparse.ArgumentParser(description="OpenMic Bridge — Web variant server")
    parser.add_argument("--port", type=int, default=8080)
    args = parser.parse_args()

    setup_virtual_mic()

    app = web.Application()
    app.router.add_get("/", index)
    app.router.add_get("/ws", websocket_handler)
    app.router.add_static("/", PUBLIC_DIR)

    print(f"[ok] Server running at http://0.0.0.0:{args.port}")
    print("     On your phone's browser, go to: http://<this-PC's-LAN-IP>:" + str(args.port))
    print("     (see README.md for the one-time Chrome flag you need on the phone)")
    web.run_app(app, host="0.0.0.0", port=args.port, print=None)


if __name__ == "__main__":
    main()
