// audio-processor.js
// Runs on the dedicated audio rendering thread. Receives Float32 audio
// frames from the mic, converts to 16-bit PCM, and posts them to the
// main thread for sending over the WebSocket. No downsampling here —
// we stream at whatever sample rate the browser's AudioContext gives us
// and tell the server that rate in the "start" message.

class OpenMicProcessor extends AudioWorkletProcessor {
  process(inputs) {
    const input = inputs[0];
    if (!input || input.length === 0) return true;

    const channelData = input[0]; // mono
    if (!channelData || channelData.length === 0) return true;

    // Convert Float32 [-1, 1] to Int16 PCM.
    const pcm = new Int16Array(channelData.length);
    for (let i = 0; i < channelData.length; i++) {
      const s = Math.max(-1, Math.min(1, channelData[i]));
      pcm[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }

    this.port.postMessage(pcm.buffer, [pcm.buffer]);
    return true;
  }
}

registerProcessor("openmic-processor", OpenMicProcessor);
