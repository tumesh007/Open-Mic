#!/usr/bin/env python3
"""
OpenMic Bridge — Web variant server.

Serves the phone-side web page (public/) and accepts a WebSocket audio
stream from it, piping the PCM into the same PipeWire virtual mic used
by the native-client version (openmic_sink / openmic_bridge).

No Android app, no build step on the phone side — just a browser.

Usage:
    python3 server.py [--port 8080]

Requires: aiohttp (pip install aiohttp --break-system-packages)
          pactl / paplay (pipewire-pulse, default on Ubuntu 24.04+)
"""

import argparse
import asyncio
import json
import shutil
import subprocess
import sys
from pathlib import Path

from aiohttp import web, WSMsgType

SINK_NAME = "openmic_sink"
SOURCE_NAME = "openmic_bridge"
VIDEO_DEVICE = "/dev/video10"
VIDEO_CARD_LABEL = "OpenMicBridgeCam"
NOISE_MODEL = Path(__file__).parent / "models" / "std.rnnn"
PUBLIC_DIR = Path(__file__).parent / "public"


def run_cmd(cmd, ignore_errors=False):
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0 and not ignore_errors:
        print(f"[warn] command failed: {' '.join(cmd)}\n{result.stderr.strip()}", file=sys.stderr)
    return result


def setup_virtual_mic():
    sinks = run_cmd(["pactl", "list", "short", "sinks"]).stdout
    if SINK_NAME not in sinks:
        run_cmd(["pactl", "load-module", "module-null-sink",
                  f"sink_name={SINK_NAME}", "sink_properties=device.description=OpenMicBridge_Sink"])
    sources = run_cmd(["pactl", "list", "short", "sources"]).stdout
    if SOURCE_NAME not in sources:
        run_cmd(["pactl", "load-module", "module-remap-source",
                  f"master={SINK_NAME}.monitor", f"source_name={SOURCE_NAME}",
                  "source_properties=device.description=OpenMicBridge"])
    print(f"[ok] Virtual mic '{SOURCE_NAME}' ready — select it as the input device in your apps.")


def setup_virtual_camera():
    """
    Best-effort v4l2loopback setup. Experimental — does not run unless
    --video is passed, and never touches the working audio path.
    Requires: sudo apt install v4l2loopback-dkms
    """
    if Path(VIDEO_DEVICE).exists():
        print(f"[ok] {VIDEO_DEVICE} already exists — assuming v4l2loopback is already loaded.")
        return True

    check = run_cmd(["modinfo", "v4l2loopback"], ignore_errors=True)
    if check.returncode != 0:
        print("[error] v4l2loopback kernel module not installed.", file=sys.stderr)
        print("        Install it with: sudo apt install v4l2loopback-dkms", file=sys.stderr)
        return False

    result = run_cmd([
        "sudo", "modprobe", "v4l2loopback",
        "video_nr=10",
        f'card_label={VIDEO_CARD_LABEL}',
        "exclusive_caps=1",
    ])
    if result.returncode != 0:
        return False

    print(f"[ok] Virtual camera created at {VIDEO_DEVICE} ('{VIDEO_CARD_LABEL}')")
    return True


def spawn_audio_player(rate, channels, denoise):
    """
    Returns a subprocess with a stdin pipe expecting raw s16le PCM at the
    given rate/channels, writing into the openmic_sink. When denoise is
    True, runs audio through ffmpeg's arnndn (RNNoise) filter first —
    this adds real CPU cost and a small amount of latency, which is why
    it's opt-in via --denoise rather than always on.
    """
    if denoise:
        if not NOISE_MODEL.exists():
            print(f"[warn] Noise model missing at {NOISE_MODEL} — falling back to no denoise.", file=sys.stderr)
        else:
            return subprocess.Popen(
                [
                    "ffmpeg", "-loglevel", "error",
                    "-f", "s16le", "-ar", str(rate), "-ac", str(channels), "-i", "pipe:0",
                    "-af", f"aresample=48000,arnndn=m={NOISE_MODEL},aresample={rate}",
                    "-f", "pulse", SINK_NAME,
                ],
                stdin=subprocess.PIPE,
            )
    return subprocess.Popen(
        ["paplay", "--raw", f"--device={SINK_NAME}",
         f"--rate={rate}", f"--channels={channels}",
         "--format=s16le"],
        stdin=subprocess.PIPE,
    )


async def index(request):
    return web.FileResponse(PUBLIC_DIR / "index.html")


async def audio_ws_handler(request):
    ws = web.WebSocketResponse(max_msg_size=1024 * 64)
    await ws.prepare(request)

    player = None
    print(f"[ok] Phone connected (audio) from {request.remote}")

    try:
        async for msg in ws:
            if msg.type == WSMsgType.TEXT:
                data = json.loads(msg.data)
                if data.get("type") == "start":
                    rate = int(data["sampleRate"])
                    channels = int(data.get("channels", 1))
                    if player is not None:
                        player.stdin.close()
                        player.wait()
                    player = spawn_audio_player(rate, channels, request.app.get("denoise_enabled", False))
                    denoise_note = " (denoised)" if request.app.get("denoise_enabled") else ""
                    print(f"[ok] Audio streaming started @ {rate} Hz, {channels} ch{denoise_note}")
                elif data.get("type") == "stop":
                    if player is not None:
                        player.stdin.close()
                        player.wait()
                        player = None
                    print("[ok] Audio streaming stopped")

            elif msg.type == WSMsgType.BINARY:
                if player is not None:
                    try:
                        player.stdin.write(msg.data)
                    except BrokenPipeError:
                        print("[error] paplay died — is pipewire-pulse running?", file=sys.stderr)
                        player = None

            elif msg.type == WSMsgType.ERROR:
                print(f"[error] audio websocket error: {ws.exception()}", file=sys.stderr)

    finally:
        if player is not None:
            try:
                player.stdin.close()
                player.wait(timeout=2)
            except Exception:
                pass
        print("[ok] Phone disconnected (audio)")

    return ws


async def video_ws_handler(request):
    """
    Experimental. Receives a stream of concatenated JPEG frames and pipes
    them into the v4l2loopback device via ffmpeg's mjpeg demuxer. Kept
    entirely separate from the audio path — a bug or crash here cannot
    affect the working mic pipeline.
    """
    if not request.app.get("video_enabled"):
        return web.Response(status=404, text="Video not enabled (start server with --video)")

    ws = web.WebSocketResponse(max_msg_size=1024 * 1024)  # frames are bigger than audio chunks
    await ws.prepare(request)

    ffmpeg_proc = None
    print(f"[ok] Phone connected (video) from {request.remote}")

    try:
        async for msg in ws:
            if msg.type == WSMsgType.TEXT:
                data = json.loads(msg.data)
                if data.get("type") == "start":
                    if ffmpeg_proc is not None:
                        ffmpeg_proc.stdin.close()
                        ffmpeg_proc.wait()
                    ffmpeg_proc = subprocess.Popen(
                        [
                            "ffmpeg", "-loglevel", "error",
                            "-f", "mjpeg", "-i", "pipe:0",
                            "-pix_fmt", "yuv420p",
                            "-f", "v4l2", VIDEO_DEVICE,
                        ],
                        stdin=subprocess.PIPE,
                    )
                    print("[ok] Video streaming started")
                elif data.get("type") == "stop":
                    if ffmpeg_proc is not None:
                        ffmpeg_proc.stdin.close()
                        ffmpeg_proc.wait()
                        ffmpeg_proc = None
                    print("[ok] Video streaming stopped")

            elif msg.type == WSMsgType.BINARY:
                if ffmpeg_proc is not None:
                    try:
                        ffmpeg_proc.stdin.write(msg.data)
                    except BrokenPipeError:
                        print("[error] ffmpeg died — check v4l2loopback is loaded", file=sys.stderr)
                        ffmpeg_proc = None

            elif msg.type == WSMsgType.ERROR:
                print(f"[error] video websocket error: {ws.exception()}", file=sys.stderr)

    finally:
        if ffmpeg_proc is not None:
            try:
                ffmpeg_proc.stdin.close()
                ffmpeg_proc.wait(timeout=2)
            except Exception:
                pass
        print("[ok] Phone disconnected (video)")

    return ws


def main():
    parser = argparse.ArgumentParser(description="OpenMic Bridge — Web variant server")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--video", action="store_true",
                         help="Enable experimental video (webcam) support alongside audio")
    parser.add_argument("--denoise", action="store_true",
                         help="Run audio through RNNoise (ffmpeg arnndn filter) to suppress "
                              "background noise (TV, fans, etc). Adds CPU cost and a little latency.")
    args = parser.parse_args()

    setup_virtual_mic()

    if args.denoise and not NOISE_MODEL.exists():
        print(f"[error] --denoise requested but model file missing: {NOISE_MODEL}", file=sys.stderr)
        print("        Continuing without denoise.", file=sys.stderr)

    video_enabled = False
    if args.video:
        if shutil.which("ffmpeg") is None:
            print("[error] ffmpeg not found. Install it: sudo apt install ffmpeg", file=sys.stderr)
        else:
            video_enabled = setup_virtual_camera()
        if not video_enabled:
            print("[warn] Continuing with audio only — video setup failed.", file=sys.stderr)

    app = web.Application()
    app["video_enabled"] = video_enabled
    app["denoise_enabled"] = args.denoise and NOISE_MODEL.exists()
    app.router.add_get("/", index)
    app.router.add_get("/ws", audio_ws_handler)
    app.router.add_get("/ws-video", video_ws_handler)
    app.router.add_static("/", PUBLIC_DIR)

    print(f"[ok] Server running at http://0.0.0.0:{args.port}")
    print("     On your phone's browser, go to: http://<this-PC's-LAN-IP>:" + str(args.port))
    if video_enabled:
        print(f"     Video enabled — virtual camera at {VIDEO_DEVICE}")
    if app["denoise_enabled"]:
        print("     Denoise enabled — audio passes through RNNoise before reaching the virtual mic")
    web.run_app(app, host="0.0.0.0", port=args.port, print=None)


if __name__ == "__main__":
    main()
