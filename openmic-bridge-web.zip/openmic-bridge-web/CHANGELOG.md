# Changelog

## v2.0.0

### Added
- **Camera (video) support**, opt-in via `--video` flag on the server
  and an independent "Start video" button on the client — fully
  separate WebSocket path from audio, so a video failure cannot affect
  the working mic pipeline.
- Front/rear camera switch button.
- `install_autostart.sh` now sets up video dependencies end-to-end:
  `ffmpeg`, `v4l2loopback` (with automatic fallback to building
  upstream source if the distro-packaged DKMS module fails to build
  against a newer kernel), persistent virtual camera across reboots
  via `/etc/modprobe.d` + `/etc/modules-load.d`, and `video` group
  membership.
- WebSocket auto-reconnect with exponential backoff on the audio path,
  so a WiFi blip mid-stream recovers without manually restarting.
- Wake Lock re-acquisition on tab visibility change, so the phone
  screen staying on actually survives brief app switches/notifications.
- `install_autostart.sh` now verifies dependencies (aiohttp,
  pipewire-pulse) are actually installed rather than assuming a prior
  manual setup already handled it, and checks the service actually
  started at the end.

### Known limitations (video)
- ~10fps, JPEG-per-frame — noticeably laggy, usable but not smooth.
- No resolution negotiation.
- No reconnect logic yet on the video WebSocket (audio has it).

## v1.0.0

- Initial release: phone browser as a mic client (no native app
  required), Linux PipeWire virtual microphone, systemd autostart.
- Parked native Android/Kotlin client and UDP protocol, kept in
  `native/` for reference.
