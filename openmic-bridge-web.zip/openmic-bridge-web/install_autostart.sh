#!/usr/bin/env bash
# Sets up OpenMic Bridge (web variant, v2 — audio + video) to auto-start
# on login/boot. Safe to re-run on the same machine or a fresh one.
set -e

INSTALL_DIR="$HOME/openmic-bridge-web"
SERVICE_DIR="$HOME/.config/systemd/user"
VIDEO_NR=10
CARD_LABEL="OpenMicBridgeCam"

echo "== [1/6] Checking audio dependencies (pactl / paplay — PipeWire) =="
MISSING_SYS=""
command -v pactl >/dev/null 2>&1 || MISSING_SYS="$MISSING_SYS pipewire-pulse"
command -v paplay >/dev/null 2>&1 || MISSING_SYS="$MISSING_SYS pulseaudio-utils"
if [ -n "$MISSING_SYS" ]; then
    echo "Installing missing packages:$MISSING_SYS"
    sudo apt update -qq
    sudo apt install -y $MISSING_SYS
else
    echo "[ok] pactl and paplay already present."
fi

echo
echo "== [2/6] Checking Python dependency (aiohttp) =="
if python3 -c "import aiohttp" >/dev/null 2>&1; then
    echo "[ok] aiohttp already installed."
else
    echo "aiohttp not found — installing..."
    if pip3 install aiohttp --break-system-packages >/dev/null 2>&1; then
        echo "[ok] Installed aiohttp via pip."
    else
        echo "pip install failed — trying apt instead."
        sudo apt update -qq
        sudo apt install -y python3-aiohttp
    fi
    python3 -c "import aiohttp" || {
        echo "[FAIL] aiohttp still not importable. Install manually:"
        echo "       pip3 install aiohttp --break-system-packages"
        exit 1
    }
fi

echo
echo "== [3/6] Checking video dependencies (ffmpeg, v4l2loopback) =="
command -v ffmpeg >/dev/null 2>&1 || { echo "Installing ffmpeg..."; sudo apt update -qq; sudo apt install -y ffmpeg; }

VIDEO_OK=false
if modinfo v4l2loopback >/dev/null 2>&1; then
    echo "[ok] v4l2loopback module already buildable/present."
    VIDEO_OK=true
else
    echo "Trying Ubuntu's packaged v4l2loopback-dkms first..."
    sudo apt update -qq
    if sudo apt install -y v4l2loopback-dkms 2>/tmp/v4l2loopback_apt.log; then
        if modinfo v4l2loopback >/dev/null 2>&1; then
            VIDEO_OK=true
        fi
    fi

    if [ "$VIDEO_OK" = false ]; then
        echo "Packaged version failed to build (common on newer kernels — the"
        echo "packaged source predates a kernel API change). Building upstream"
        echo "source instead, which has the fix..."
        sudo apt purge -y v4l2loopback-dkms >/dev/null 2>&1 || true
        sudo dpkg --configure -a >/dev/null 2>&1 || true
        sudo apt install -y git build-essential dkms "linux-headers-$(uname -r)"

        BUILD_DIR="$(mktemp -d)"
        git clone --depth 1 https://github.com/umlaeute/v4l2loopback.git "$BUILD_DIR/v4l2loopback"
        cd "$BUILD_DIR/v4l2loopback"
        V4L2_VERSION="$(grep -m1 '^PACKAGE_VERSION' dkms.conf | cut -d'"' -f2)"

        sudo dkms remove "v4l2loopback/$V4L2_VERSION" --all >/dev/null 2>&1 || true
        sudo dkms add .
        sudo dkms build "v4l2loopback/$V4L2_VERSION"
        sudo dkms install "v4l2loopback/$V4L2_VERSION"
        cd - >/dev/null
        rm -rf "$BUILD_DIR"

        modinfo v4l2loopback >/dev/null 2>&1 && VIDEO_OK=true
    fi
fi

if [ "$VIDEO_OK" = true ]; then
    echo "[ok] v4l2loopback module ready."
else
    echo "[warn] Could not get v4l2loopback working — continuing with audio only."
    echo "       Video will simply stay disabled; nothing else is affected."
fi

echo
echo "== [4/6] Making the virtual camera persistent across reboots =="
if [ "$VIDEO_OK" = true ]; then
    echo "options v4l2loopback video_nr=$VIDEO_NR card_label=$CARD_LABEL exclusive_caps=1" | \
        sudo tee /etc/modprobe.d/openmic-bridge-v4l2loopback.conf >/dev/null
    echo "v4l2loopback" | sudo tee /etc/modules-load.d/openmic-bridge-v4l2loopback.conf >/dev/null

    # Load it now too, so it's usable immediately without a reboot.
    sudo modprobe -r v4l2loopback >/dev/null 2>&1 || true
    sudo modprobe v4l2loopback video_nr=$VIDEO_NR card_label="$CARD_LABEL" exclusive_caps=1

    echo "[ok] /dev/video$VIDEO_NR will be created automatically on every boot."
    echo "     (This is what lets the server use it without ever needing sudo"
    echo "     at runtime — important since systemd can't prompt for a password.)"

    echo
    echo "== [5/6] Checking you can access the camera device without sudo =="
    if groups | grep -qw video; then
        echo "[ok] Already in the 'video' group."
    else
        echo "Adding you to the 'video' group..."
        sudo usermod -aG video "$USER"
        echo "[warn] This only takes effect after you log out and back in."
        echo "       Until then, video streaming may still fail with a"
        echo "       permissions error even though everything else is set up."
    fi
else
    echo "== [5/6] Skipped (video not available) =="
fi

echo
echo "== [6/6] Installing to $INSTALL_DIR and setting up autostart =="
mkdir -p "$INSTALL_DIR"
if command -v rsync >/dev/null 2>&1; then
    rsync -a --exclude 'install_autostart.sh' --exclude '*.service' ./ "$INSTALL_DIR/"
else
    cp -r ./* "$INSTALL_DIR/" 2>/dev/null
fi

mkdir -p "$SERVICE_DIR"
if [ "$VIDEO_OK" = true ]; then
    sed "s|--port 8080|--port 8080 --video|" openmic-bridge-web.service > "$SERVICE_DIR/openmic-bridge-web.service"
    echo "[ok] Service will start with --video enabled."
else
    cp openmic-bridge-web.service "$SERVICE_DIR/"
    echo "[ok] Service will start audio-only (video unavailable on this machine)."
fi

loginctl enable-linger "$USER"
systemctl --user daemon-reload
systemctl --user enable --now openmic-bridge-web.service

sleep 1
echo
if systemctl --user is-active --quiet openmic-bridge-web.service; then
    echo "[ok] Service is running."
else
    echo "[FAIL] Service did not start. Debug with:"
    echo "       cd $INSTALL_DIR && python3 server.py --port 8080 $( [ "$VIDEO_OK" = true ] && echo '--video' )"
fi

echo
echo "Check status:   systemctl --user status openmic-bridge-web.service"
echo "View logs:      journalctl --user -u openmic-bridge-web.service -f"
echo "Stop:           systemctl --user stop openmic-bridge-web.service"
echo "Disable:        systemctl --user disable openmic-bridge-web.service"
if [ "$VIDEO_OK" = true ] && ! groups | grep -qw video; then
    echo
    echo "[action needed] Log out and back in for camera access to work —"
    echo "                the 'video' group membership added above isn't"
    echo "                active in your current session yet."
fi
